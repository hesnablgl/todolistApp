package com.example.todolistapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.time.Instant;
import java.util.ArrayList;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.MyViewHolder> {

    Context context;
    ArrayList<MyTasks> myTasks;

    public TaskAdapter(Context c, ArrayList<MyTasks> p){
        context = c;
        myTasks = p;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.item_do,viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int i) {
        myViewHolder.titledo.setText(myTasks.get(i).getTitledo());
        myViewHolder.descdo.setText(myTasks.get(i).getDescdo());
        myViewHolder.datedo.setText(myTasks.get(i).getDatedo());

        final String getTitleDo = myTasks.get(i).getTitledo();
        final String getDescDo = myTasks.get(i).getDescdo();
        final String getDateDo = myTasks.get(i).getDatedo();
        final String getKeyDo = myTasks.get(i).getKeydo();

        myViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent aa= new Intent(context, EditTaskDesk.class);
                aa.putExtra("titledo", getTitleDo);
                aa.putExtra("descdo", getDescDo);
                aa.putExtra("datedo", getDateDo);
                aa.putExtra("keydo", getKeyDo);
                context.startActivity(aa);
            }
        });
    }

    @Override
    public int getItemCount() {
        return myTasks.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{

        TextView titledo, descdo, datedo, keydo;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            titledo = (TextView) itemView.findViewById(R.id.titledo);
            descdo = (TextView) itemView.findViewById(R.id.descdo);
            datedo = (TextView) itemView.findViewById(R.id.datedo);

        }
    }
}
