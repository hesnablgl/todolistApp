package com.example.todolistapp;

public class MyTasks {
    String titledo;
    String datedo;
    String descdo;
    String keydo;

    public MyTasks() {
    }

    public MyTasks(String titledo, String datedo, String descdo, String keydo) {
        this.titledo = titledo;
        this.datedo = datedo;
        this.descdo = descdo;
        this.keydo = keydo;
    }

    public String getKeydo() {
        return keydo;
    }

    public void setKeydo(String keydo) {
        this.keydo = keydo;
    }

    public String getTitledo() {
        return titledo;
    }

    public void setTitledo(String titledo) {
        this.titledo = titledo;
    }

    public String getDatedo() {
        return datedo;
    }

    public void setDatedo(String datedo) {
        this.datedo = datedo;
    }

    public String getDescdo() {
        return descdo;
    }

    public void setDescdo(String descdo) {
        this.descdo = descdo;
    }
}
